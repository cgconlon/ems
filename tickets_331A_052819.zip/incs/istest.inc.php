<?php
//$istest = TRUE;
$istest = FALSE;
$snap_table = "snap_data";

/*
CREATE TABLE IF NOT EXISTS `snap_data` (
	`id` int(4) NOT NULL AUTO_INCREMENT,
	`source` varchar(256),
	`stuff` varchar(2048),
	`when` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
	PRIMARY KEY (`id`)
	) ENGINE=MyISAM  DEFAULT CHARSET=latin1 ;

*/
error_reporting(E_ALL);
?>