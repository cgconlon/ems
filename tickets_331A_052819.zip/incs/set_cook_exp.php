<?php
/*
1/11/10 initial release - updates user cookie expiration
*/
error_reporting(E_ALL);	

require_once($fip);		//7/28/10
set_sess_exp();
print "";
?>
