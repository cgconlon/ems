<?php
	$body 			= "text-align: center; BACKGROUND-COLOR: #EFEFEF; MARGIN:0; FONT-WEIGHT: normal; COLOR: #000000; FONT-FAMILY: Verdana, Arial, Helvetica, sans-serif;TEXT-DECORATION: none";
	$table 			= "table-layout: fixed; border-collapse: collapse; border:1px solid black; text-align: left; background-color: white; FONT-SIZE: 1em;";
	$upper 			= "border-collapse: collapse; border:none;";
	$inner			= "width:100%; border-collapse: collapse; border:none;";

	$tr_fat 		= "background-color: white; height: 40px; vertical-align:text-top;";
	$tr_thin 		= "background-color: white; height: 19px; vertical-align:middle;";
	$tr_plain 		= "background-color: white; height: 19px;";

	$td_plain		= "FONT-WEIGHT: 500; FONT-SIZE: .9em; border:1px solid black; text-align: left; white-space: nowrap;";
	$td_heading		= "FONT-WEIGHT: 900; FONT-SIZE: .9em; border:1px solid black; text-align: left; white-space: nowrap;";
	$td_heading_nb	= "FONT-WEIGHT: 900; FONT-SIZE: .9em; border:none; 			  text-align: left; white-space: nowrap;";
	$td_heading_c	= "FONT-WEIGHT: 400; FONT-SIZE: .9em; border:1px solid black; text-align: center; white-space: nowrap;";
	$vertical 		= "FONT-WEIGHT: 900; FONT-SIZE: .9em; text-align: center;";
	$input			= "font-size: inherit; font-family: monospace;";
	$textarea  		= "font-size: inherit; font-family: monospace;";

?>