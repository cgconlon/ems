<?php
/*
*/
error_reporting(E_ALL);	
require_once('./incs/functions.inc.php');
do_aprs();

print "finished finished finished finished finished finished ";

?>
